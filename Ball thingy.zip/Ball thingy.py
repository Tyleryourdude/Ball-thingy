import pygame
import random
import time
import os
import platform

# Initialize Pygame
pygame.init()

# Get the path to the user's desktop
if platform.system() == "Windows":
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
elif platform.system() == "Darwin":  # macOS
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
else:  # Assuming Linux or other
    desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")

# Define the log file path on desktop
LOG_FILE = os.path.join(desktop_path, "bounce_log.txt")

# Set up constants
FPS = 60
CIRCLE_RADIUS = 30  # Initial size of the balls
MIN_BALL_SPEED = 3  # Minimum ball speed
MAX_BALL_SPEED = 8  # Maximum ball speed
DEFAULT_BALL_APPEAR_INTERVAL = 90  # Default balls will appear every 90 seconds
BRIGHTNESS_THRESHOLD = 100  # Threshold for "dark" color
SECRET_BALLS_TO_ADD = 1  # Number of balls to add when 'P' is pressed
SECRET_BALLS_TO_ADD_L = 10  # Number of balls to add when 'L' is pressed
BALL_TRAIL_LENGTH = 10  # Length of the trail
SILVER_BALL_APPEAR_INTERVAL = 1500  # Interval for the silver ball to appear (25 minutes)

# Initialize the display
screen = pygame.display.set_mode((0, 0), pygame.NOFRAME)  # Borderless window mode
width, height = pygame.display.Info().current_w, pygame.display.Info().current_h  # Get the current screen size
pygame.display.set_caption('Bouncing Ball Effect')
clock = pygame.time.Clock()

# List to hold balls
balls = []

# Global variables
bounce_count = 0
admin_panel_active = False  # Indicates if the admin panel is active
password_requested = False  # State to indicate if password is requested
password_input = ''  # To store user's input
correct_password = 'CVNB'  # The correct password
ball_appear_interval = DEFAULT_BALL_APPEAR_INTERVAL  # Time between balls
next_ball_time_offset = 30  # Countdown starts 30 seconds before the next ball
show_timer = True  # Variable to indicate if the countdown timer is shown
ball_speed_factor = 1.0  # Factor to adjust the current speed of all balls
paused = False  # State to indicate if the game is paused
show_ball_count = True  # To control visibility of ball count display
background_color = (0, 0, 0)
background_colors = [
    (0, 0, 0), (50, 50, 50), (100, 100, 255), (255, 255, 255), (255, 0, 0)
]
current_ball_size_index = 1  # Start with the default size

# Special ball variables
special_ball = None  # To store the special ball information
special_ball_spawn_time = None  # To track the spawn time of the special ball
SPECIAL_BALL_LIFETIME = 10  # Duration for which the special ball remains visible
silver_ball = None  # To track silver ball
next_silver_ball_time = time.time() + SILVER_BALL_APPEAR_INTERVAL  # Set to far in the future

# License Agreement Variables
license_visible = False  # To track if the license agreement box is visible
# Increase the dimensions of the license box (width, height)
license_box_rect = pygame.Rect(width // 4, height // 4, width // 2, height // 2)  # Define a rectangle for the box

license_text = [
    "Hello, thanks for downloading this program!",
    "Before you can use it, here are a few important precautionary measures:",
    "1. If someone makes you buy this program with money, you are an idiot and a victim of piracy.",
    "2. Delete the version at all costs and obtain the real version at https://github.com/Tyleryourdude/Ball-thingy.",
    "3. This program is completely free and should not be sold.",
    "4. Using pirated software may expose your system to malicious software.",
    "5. Always download from trusted sources.",
    "6. Ensure this software does not conflict with your current system.",
    "7. If you encounter any issues, feel free to contact me at tyler343a4@gmail.com.",
    "8. By using this software, you agree to these terms."
]

# Function to generate a random color
def random_color():
    return (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

# Function to initialize a new ball, with a chance to create a special ball
def init_ball(x, y):
    if random.randint(1, 1000000000) == 1:
        global special_ball, special_ball_spawn_time
        special_ball = {
            'pos': [x, y],
            'velocity': [0, 0],  # Special ball does not move
            'color': (255, 215, 0),  # Gold color for the special ball
            'size': CIRCLE_RADIUS,
            'is_special': True,  # Mark it as a special ball
        }
        special_ball_spawn_time = time.time()  # Record the spawn time
        return None  # Special ball is not added to the regular balls
    else:
        dx = random.choice([-1, 1]) * random.randint(MIN_BALL_SPEED, MAX_BALL_SPEED) * ball_speed_factor
        dy = random.choice([-1, 1]) * random.randint(MIN_BALL_SPEED, MAX_BALL_SPEED) * ball_speed_factor
        color = random_color()
        return {
            'pos': [x, y],
            'velocity': [dx, dy],
            'color': color,
            'original_color': color,
            'size': CIRCLE_RADIUS,
            'is_rainbow': False,
            'rainbow_start_time': 0,
            'trail': [],  # Store trail points
            'hidden': False  # Visibility state
        }

# Function to add a new ball
def add_ball():
    if not paused:  # Only add balls if game is not paused
        x = random.randint(CIRCLE_RADIUS, width - CIRCLE_RADIUS)
        y = random.randint(CIRCLE_RADIUS, height - CIRCLE_RADIUS)
        ball = init_ball(x, y)
        if ball:
            balls.append(ball)

# Function to create a specified number of balls
def create_random_balls(number_of_balls):
    for _ in range(number_of_balls):
        add_ball()  # Add the specified number of balls

# Function to explode balls and generate new ones
def explode_balls():
    global balls
    new_balls = []
    for ball in balls:
        for _ in range(5):  # Create 5 new balls for each exploded ball
            new_x = ball['pos'][0]
            new_y = ball['pos'][1]
            new_ball = init_ball(new_x, new_y)
            if new_ball:
                new_balls.append(new_ball)
    balls = new_balls  # Replace existing balls with the new ones

# Function to change background color
def change_background_color():
    global background_color
    current_index = background_colors.index(background_color)
    background_color = background_colors[(current_index + 1) % len(background_colors)]

# Function to toggle pause state
def toggle_pause():
    global paused
    paused = not paused  # Toggle the paused state

# Function to toggle ball count visibility
def toggle_ball_count():
    global show_ball_count
    show_ball_count = not show_ball_count  # Toggle visibility of ball count

# Function to toggle timer visibility
def toggle_timer():
    global show_timer
    show_timer = not show_timer  # Toggle visibility of timer

# Function to increase bounce count
def increase_bounce_count():
    global bounce_count
    bounce_count += 1

# Function to decrease bounce count
def decrease_bounce_count():
    global bounce_count
    bounce_count = max(0, bounce_count - 1)

# Function to reset the game
def reset_game():
    global bounce_count, balls, special_ball, silver_ball
    bounce_count = 0
    balls = []  # Clear all balls
    special_ball = None  # Reset special ball
    silver_ball = None  # Reset silver ball

# Function to change ball size
def change_ball_size():
    global current_ball_size_index
    current_ball_size_index = (current_ball_size_index + 1) % len(ball_sizes)  # Cycle through ball sizes
    for ball in balls:
        ball['size'] = ball_sizes[current_ball_size_index]  # Update the size

# Function to randomize all ball colors
def randomize_ball_colors():
    for ball in balls:
        ball['color'] = random_color()  # Change to new random color

# Function to toggle rainbow mode for balls
def toggle_rainbow_mode():
    for ball in balls:
        ball['is_rainbow'] = not ball['is_rainbow']  # Toggle rainbow mode

# Function to speed up all balls
def speed_up_balls():
    global ball_speed_factor
    ball_speed_factor *= 1.2  # Increase speed by 20%

# Function to slow down all balls
def slow_down_balls():
    global ball_speed_factor
    ball_speed_factor = max(0.5, ball_speed_factor * 0.8)  # Decrease speed by 20%, minimum 0.5

# Function to change all balls' directions
def change_ball_direction():
    for ball in balls:
        ball['velocity'] = [random.choice([-1, 1]) * random.randint(MIN_BALL_SPEED, MAX_BALL_SPEED) * ball_speed_factor,
                            random.choice([-1, 1]) * random.randint(MIN_BALL_SPEED, MAX_BALL_SPEED) * ball_speed_factor]

# Function to toggle visibility of all balls
def toggle_hide_show_balls():
    for ball in balls:
        ball['hidden'] = not ball['hidden']

# Function to increase the size of all balls
def increase_ball_size():
    for ball in balls:
        ball['size'] += 5  # Increase size by 5

# Function to decrease the size of all balls
def decrease_ball_size():
    for ball in balls:
        ball['size'] = max(5, ball['size'] - 5)  # Decrease size by 5, minimum size is 5

# Function to reverse the direction of all balls
def reverse_ball_directions():
    for ball in balls:
        ball['velocity'][0] = -ball['velocity'][0]  # Reverse x-direction
        ball['velocity'][1] = -ball['velocity'][1]  # Reverse y-direction

# Function to shuffle positions of all balls
def shuffle_ball_positions():
    for ball in balls:
        ball['pos'][0] = random.randint(CIRCLE_RADIUS, width - CIRCLE_RADIUS)
        ball['pos'][1] = random.randint(CIRCLE_RADIUS, height - CIRCLE_RADIUS)

# Function to equalize the speeds of all balls
def equalize_ball_speeds():
    if balls:
        average_speed = sum((abs(ball['velocity'][0]) + abs(ball['velocity'][1])) for ball in balls) / (2 * len(balls))
        for ball in balls:
            ball['velocity'] = [average_speed, average_speed]  # Set both x and y speeds to average speed

# Function to log bounce count to a file
def log_bounce_count():
    with open(LOG_FILE, 'a') as log_file:
        log_file.write(f"Bounces: {bounce_count} at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")

# Function to randomly change the shape of the balls (for illustration purposes)
def change_ball_shape():
    global balls
    for ball in balls:
        ball['shape'] = 'square' if 'shape' not in ball or ball['shape'] == 'circle' else 'circle'  # Toggle shape

# Function to randomize ball sizes
def randomize_ball_sizes():
    global balls
    for ball in balls:
        ball['size'] = random.choice(ball_sizes)  # Randomly assign a new size from available sizes

# Function to add secret balls on key press
def add_secret_balls(count):
    for _ in range(count):
        add_ball()  # Add the specified number of secret balls

# Function to remove a specified number of balls
def remove_balls(count):
    global balls
    for _ in range(min(count, len(balls))):  # Remove up to 'count' balls
        balls.pop(random.randint(0, len(balls) - 1))

# Function to flash all balls to yellow
def flash_balls():
    for ball in balls:
        ball['color'] = (255, 255, 0)  # Change color to yellow

# Main loop
running = True
start_time = time.time()
next_ball_time = start_time + ball_appear_interval

# Initial ball
add_ball()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:  # Check if the window is closed
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:  # Press ESC to exit
                running = False
            elif event.key == pygame.K_a:  # Press 'A' to request password
                password_requested = True
                password_input = ''  # Reset input
            elif event.key == pygame.K_RETURN and password_requested:  # Check the password entry
                if password_input == correct_password:
                    admin_panel_active = True  # Activate admin panel if the password is correct
                password_requested = False  # Reset after checking
                password_input = ''  # Clear input
            elif event.key == pygame.K_BACKSPACE and password_requested:  # Handle backspace
                password_input = password_input[:-1]  # Remove the last character
            elif password_requested:  # Only add letters if we're in password mode
                if len(password_input) < 10:  # Max length
                    password_input += event.unicode  # Capture the input
            # Secret key actions
            if event.key == pygame.K_p:  # Add secret balls
                add_secret_balls(SECRET_BALLS_TO_ADD)  # Add the specified number of secret balls
            elif event.key == pygame.K_l:  # Add more secret balls
                add_secret_balls(SECRET_BALLS_TO_ADD_L)
            elif event.key == pygame.K_r:  # Log bounce count
                log_bounce_count()

        # Handle mouse events for buttons
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # Left mouse button click
            mouse_x, mouse_y = event.pos
            
            # Show/hide license agreement
            license_button_rect = pygame.Rect(width - 150, height - 50, 140, 40)
            if license_button_rect.collidepoint(mouse_x, mouse_y):
                license_visible = not license_visible  # Toggle visibility
            
            # Admin panel actions
            if admin_panel_active:
                buttons = [
                    {"text": "Increase Bounces", "action": increase_bounce_count, "rect": pygame.Rect(10, 60, 150, 35)},
                    {"text": "Decrease Bounces", "action": decrease_bounce_count, "rect": pygame.Rect(10, 100, 150, 35)},
                    {"text": "Change Background", "action": change_background_color, "rect": pygame.Rect(10, 140, 150, 35)},
                    {"text": "Explode Balls", "action": explode_balls, "rect": pygame.Rect(10, 180, 150, 35)},
                    {"text": "Toggle Pause", "action": toggle_pause, "rect": pygame.Rect(10, 220, 150, 35)},
                    {"text": "Toggle Ball Count", "action": toggle_ball_count, "rect": pygame.Rect(10, 260, 150, 35)},
                    {"text": "Toggle Timer", "action": toggle_timer, "rect": pygame.Rect(10, 300, 150, 35)},
                    {"text": "Reset Game", "action": reset_game, "rect": pygame.Rect(10, 340, 150, 35)},
                    {"text": "Change Ball Size", "action": change_ball_size, "rect": pygame.Rect(10, 380, 150, 35)},
                    {"text": "Randomize Colors", "action": randomize_ball_colors, "rect": pygame.Rect(10, 420, 150, 35)},
                    {"text": "Toggle Rainbow", "action": toggle_rainbow_mode, "rect": pygame.Rect(10, 460, 150, 35)},
                    {"text": "Speed Up Balls", "action": speed_up_balls, "rect": pygame.Rect(10, 500, 150, 35)},
                    {"text": "Slow Down Balls", "action": slow_down_balls, "rect": pygame.Rect(10, 540, 150, 35)},
                    {"text": "Change Direction", "action": change_ball_direction, "rect": pygame.Rect(10, 580, 150, 35)},
                    {"text": "Hide/Show Balls", "action": toggle_hide_show_balls, "rect": pygame.Rect(10, 620, 150, 35)},
                    {"text": "Increase Ball Size", "action": increase_ball_size, "rect": pygame.Rect(10, 660, 150, 35)},
                    {"text": "Decrease Ball Size", "action": decrease_ball_size, "rect": pygame.Rect(10, 700, 150, 35)},
                    {"text": "Reverse Directions", "action": reverse_ball_directions, "rect": pygame.Rect(10, 740, 150, 35)},
                    {"text": "Shuffle Positions", "action": shuffle_ball_positions, "rect": pygame.Rect(10, 780, 150, 35)},
                    {"text": "Equalize Speeds", "action": equalize_ball_speeds, "rect": pygame.Rect(10, 820, 150, 35)},
                    {"text": "Randomize Sizes", "action": randomize_ball_sizes, "rect": pygame.Rect(10, 860, 150, 35)},
                    {"text": "Change Shape", "action": change_ball_shape, "rect": pygame.Rect(10, 900, 150, 35)},
                    {"text": "Add Balls", "action": lambda: add_secret_balls(5), "rect": pygame.Rect(10, 940, 150, 35)},  # Add 5 balls
                    {"text": "Remove Balls", "action": lambda: remove_balls(3), "rect": pygame.Rect(10, 980, 150, 35)},  # Remove 3 balls
                    {"text": "Flash Balls", "action": flash_balls, "rect": pygame.Rect(10, 1020, 150, 35)},  # New flash balls button
                ]

                # Check if any button is clicked
                for button in buttons:
                    if button['rect'].collidepoint(mouse_x, mouse_y):
                        button['action']()  # Call the button action

    current_time = time.time()

    # Manage special ball appearance
    if special_ball:
        if current_time - special_ball_spawn_time > SPECIAL_BALL_LIFETIME:
            special_ball = None  # Remove the special ball after its lifetime has passed

    # Manage silver ball appearance
    if silver_ball is None and current_time >= next_silver_ball_time:
        silver_ball = {
            'pos': [random.randint(CIRCLE_RADIUS, width - CIRCLE_RADIUS), random.randint(CIRCLE_RADIUS, height - CIRCLE_RADIUS)],
            'color': (192, 192, 192),  # Silver color
            'size': CIRCLE_RADIUS,
        }
        next_silver_ball_time = current_time + SILVER_BALL_APPEAR_INTERVAL  # Schedule the next silver ball appearance
    
    # Check if silver ball was clicked
    if silver_ball and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # Left mouse button click
        mouse_x, mouse_y = event.pos
        if (silver_ball['pos'][0] - silver_ball['size'] < mouse_x < silver_ball['pos'][0] + silver_ball['size'] and
            silver_ball['pos'][1] - silver_ball['size'] < mouse_y < silver_ball['pos'][1] + silver_ball['size']):
            create_random_balls(random.randint(10, 20))  # Create between 10 and 20 new balls
            silver_ball = None  # Remove the silver ball after clicking

    # Check if we need to add a new ball automatically if not paused
    if current_time >= next_ball_time and not paused:
        add_ball()
        next_ball_time = current_time + ball_appear_interval  # Schedule the next ball

    # Update and draw all balls if not paused
    if not paused:
        screen.fill(background_color)  # Fill the screen with the selected background color
        for ball in balls:
            if not ball.get('hidden', False):  # Update the ball's position if not hidden
                ball['pos'][0] += ball['velocity'][0]
                ball['pos'][1] += ball['velocity'][1]

                # Collision checks
                if (ball['pos'][0] - ball['size'] < 0) or (ball['pos'][0] + ball['size'] > width):
                    ball['velocity'][0] = -ball['velocity'][0]
                    bounce_count += 1
                    ball['color'] = random_color()
                if (ball['pos'][1] - ball['size'] < 0) or (ball['pos'][1] + ball['size'] > height):
                    ball['velocity'][1] = -ball['velocity'][1]
                    bounce_count += 1
                    ball['color'] = random_color()
                
                # Draw the ball
                draw_color = ball['color']
                shape = ball.get('shape', 'circle')
                if shape == 'square':
                    pygame.draw.rect(screen, draw_color, (int(ball['pos'][0]) - ball['size'] // 2, int(ball['pos'][1]) - ball['size'] // 2, ball['size'], ball['size']))
                else:
                    if sum(draw_color) < BRIGHTNESS_THRESHOLD:
                        highlight_color = (min(draw_color[0] + 50, 255), min(draw_color[1] + 50, 255), min(draw_color[2] + 50, 255))
                        pygame.draw.circle(screen, highlight_color, (int(ball['pos'][0]), int(ball['pos'][1])), ball['size'] + 5)
                    pygame.draw.circle(screen, ball['color'], (int(ball['pos'][0]), int(ball['pos'][1])), ball['size'])

        # Draw the special ball if it exists
        if special_ball:
            pygame.draw.circle(screen, special_ball['color'], (int(special_ball['pos'][0]), int(special_ball['pos'][1])), special_ball['size'])
            pygame.draw.circle(screen, (0, 0, 0), (int(special_ball['pos'][0]), int(special_ball['pos'][1])), special_ball['size'] + 5, 2)  # Black outline

        # Draw the silver ball if it exists
        if silver_ball:
            pygame.draw.circle(screen, silver_ball['color'], (int(silver_ball['pos'][0]), int(silver_ball['pos'][1])), silver_ball['size'])
            pygame.draw.circle(screen, (0, 0, 0), (int(silver_ball['pos'][0]), int(silver_ball['pos'][1])), silver_ball['size'] + 5, 2)  # Black outline

        # Draw bounce count in the upper right corner
        bounce_text = f"Bounces: {bounce_count}"
        font = pygame.font.Font(None, 36)
        bounce_surface = font.render(bounce_text, True, (255, 255, 255))  # White text
        screen.blit(bounce_surface, (width - bounce_surface.get_width() - 10, 10))  # Position it in the upper right corner

        # Show the total number of balls in the bottom left corner if enabled
        if show_ball_count:
            total_balls_text = f"Total Balls: {len(balls)}"
            total_balls_surface = font.render(total_balls_text, True, (255, 255, 255))  # White text
            screen.blit(total_balls_surface, (10, height - total_balls_surface.get_height() - 10))  # Position it in the bottom left corner

        # Draw the countdown timer in the center of the screen if visible
        if show_timer and (next_ball_time - current_time) <= next_ball_time_offset:
            countdown_text = f"Next ball in: {int(max(0, next_ball_time - current_time))} seconds"
            countdown_surface = font.render(countdown_text, True, (255, 255, 255))
            countdown_rect = countdown_surface.get_rect(center=(width // 2, height // 2))  # Center it on the screen
            screen.blit(countdown_surface, countdown_rect)

        # Draw license agreement button
        license_button_rect = pygame.Rect(width - 150, height - 50, 140, 40)
        pygame.draw.rect(screen, (50, 50, 50), license_button_rect)  # Dark grey button
        license_button_surface = font.render("License Agreement", True, (255, 255, 255))  # White text
        screen.blit(license_button_surface, (license_button_rect.x + 10, license_button_rect.y + 5))

        # Draw license agreement box if visible
        if license_visible:
            pygame.draw.rect(screen, (200, 200, 200), license_box_rect)  # Gray box
            for i, line in enumerate(license_text):
                line_surface = font.render(line, True, (0, 0, 0))  # Black text
                screen.blit(line_surface, (license_box_rect.x + 10, license_box_rect.y + 30 + i * 20))

    # Show password input prompt
    if password_requested:
        password_prompt_surface = font.render("Enter password:", True, (255, 255, 255))
        screen.blit(password_prompt_surface, (10, height // 2 - 50))  # Center it vertically
        password_input_surface = font.render(password_input, True, (255, 255, 255))
        screen.blit(password_input_surface, (10, height // 2 - 10))  # Position it right below the prompt

    # Update the display
    pygame.display.flip()

    # Control frames per second
    clock.tick(FPS)

# Quit Pygame after exiting the loop
pygame.quit()